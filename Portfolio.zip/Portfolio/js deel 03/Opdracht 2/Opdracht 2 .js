let dag = document.getElementsByClassName("grid");
dag[0].textContent = "Dag Yanic";

let link = document.getElementById("utag_194");
console.log ( link.textContent );
